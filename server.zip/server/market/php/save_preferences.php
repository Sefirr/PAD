﻿<?php
	// Varios defines para los parámetros de configuración de acceso a la BD y la URL desde la que se sirve la aplicación
	define('BD_HOST', 'localhost');
	define('BD_NAME', 'pray4fun_bookalive');
	define('BD_USER', 'pray4fun_balive');
	define('BD_PASS', 'A1!firo61');
	define('INSTALL', true );
	
	define('HTML5_EMAIL_REGEXP', '/^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/');


	$BD = new mysqli(BD_HOST, BD_USER, BD_PASS, BD_NAME);
	if ( $BD->connect_errno ) {
	  echo "Error de conexión a la BD: (" . $BD->connect_errno . ") " . utf8_encode($BD->connect_error);
	  exit();
	}

	if ( ! $BD->set_charset("utf8")) {
	  echo "Error al configurar la codificación de la BD: (" . $BD->errno . ") " . utf8_encode($BD->error);
	  exit();
	}

	$result = array();
	$okValidacion = TRUE;

	$username = isset($_GET['id_user']) ? $_GET['id_user'] : null ;
	$preferences = isset($_GET['preferences']) ? $_GET['preferences'] : null ;

	if ( $okValidacion ) {	
		$query = "UPDATE Preferences SET name='".$preferences['name']."',surname='".$preferences['surname']."',description='".$preferences['description']."',author='".$preferences['author']."',language='".$preferences['language']."',genre='".$preferences['genre']."'  WHERE id ='".$BD->real_escape_string($username)."'";
		$resultado = $BD->query($query);

		
		
		//send your user to the browser encoded in the JSON format
		echo json_encode(array('status' => 'success'));		
	} else {
		echo json_encode(array('status' => 'error', 'errors' => $result));
	}
	
?>