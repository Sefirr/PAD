	var URL_MARKET = "http://pray4fun.x10host.com/market/";

	var buyBook = function(id_book) {
		// Se hace select del libro y se pilla la url del servidor externo
		$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/buy.php',data:{"id":id_book}, success:function (response) {
			var book;
			
			// if the PHP script returned a success
			if (response.status == 'success') {
				book = response.book[0];
				downloadBook(URL_MARKET+ book.url +".zip", book.url, book.id);
			} else {
				alert('The book isnt available to be purchased.');
			}
		}});
	}
	
	var downloadBook = function (url, filename, id_book){
		window.requestFileSystem  = window.requestFileSystem || window.webkitRequestFileSystem;
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function (fs) {					
			
			var fileURL = encodeURI(cordova.file.dataDirectory + filename + ".zip");
			var fileTransfer = new FileTransfer();
			var uri = encodeURI(decodeURIComponent(url));
			
			fileTransfer.download(
			uri,
			fileURL,
			function(entry) {
				//alert("download complete: " + entry.toURL() + ", " + cordova.file.dataDirectory);
				var PathToFileInString  = cordova.file.dataDirectory + filename +".zip",
					PathToResultZip     = cordova.file.dataDirectory;
				JJzip.unzip(PathToFileInString, {target:PathToResultZip},function(data){
					/* Wow everything goes good, but just in case verify data.success */
					//alert(data.success);
					var url = cordova.file.dataDirectory+filename+"/";
					var user = localStorage.getItem("userSigned");
					var book = id_book;							

					$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/download.php',data:{"id_user":user,"id_book":book, "url":url}, success:function (response) {		
						var book = response.book[0];
						if(response.status == 'success') {
							alert("The book has been downloaded with success.");
						} else {
							alert("The book hasn'n been downloaded.");
						}
					},  error: function (xhr, ajaxOptions, thrownError) {
							alert(xhr.status);
							alert(thrownError);
						}});
				},function(error){
					/* Wow something goes wrong, check the error.message */
					alert(error.message);
				})
			},
			function(error) {
				alert("The book is unavailable in this moment.");
				//alert("download error source " + error.source);
				//alert("download error target " + error.target);
				//alert("upload error code " + error.code);
			});
		}, function (error) {
			alert("Some error");
		}); 
	}
	
	
	
	var accessBook = function (url) {
		var info_book = url.split('file:///').pop();
		location = "reader.html?name="+info_book;
	};