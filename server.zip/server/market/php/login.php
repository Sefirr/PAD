﻿<?php
	// Varios defines para los parámetros de configuración de acceso a la BD y la URL desde la que se sirve la aplicación
	define('BD_HOST', 'localhost');
	define('BD_NAME', 'pray4fun_bookalive');
	define('BD_USER', 'pray4fun_balive');
	define('BD_PASS', 'A1!firo61');
	define('INSTALL', true );

	$BD = new mysqli(BD_HOST, BD_USER, BD_PASS, BD_NAME);
	if ( $BD->connect_errno ) {
	  echo "Error de conexión a la BD: (" . $BD->connect_errno . ") " . utf8_encode($BD->connect_error);
	  exit();
	}

	if ( ! $BD->set_charset("utf8")) {
	  echo "Error al configurar la codificación de la BD: (" . $BD->errno . ") " . utf8_encode($BD->error);
	  exit();
	}

	$result = array();
	$okValidacion = TRUE;

	$username = isset($_GET['username']) ? $_GET['username'] : null ;
	
	if (!$username) {
		$result[] = "Username is invalid.";
		$okValidacion = FALSE;
	}

	$pass = isset($_GET['password']) ? $_GET['password'] : null ;
	if ( !$pass ||  strlen($pass) < 4 ) {
		$result[] = 'Password is invalid.';
		$okValidacion = FALSE;
	}
	
	$user = false;
	$library = false;
	$books = false;

	$library = array();
	$book = array();

	if ( $okValidacion ) {
		
		
		$query = "SELECT * FROM User WHERE username='".$BD->real_escape_string($username)."'";
		if($resultado = $BD->query($query)) {
		
		$user = $resultado->fetch_assoc();
		
		$query2 = "SELECT * FROM Book,Library WHERE Library.id_user='".$BD->real_escape_string($user["id"])."' and Book.id=Library.id_book";
		
		$resultado2 = $BD->query($query2);
		
		while($row2 = $resultado2->fetch_assoc()) {
			$books[] = $row2;				
		}
		
		
		$query3 = "SELECT * FROM User,Library WHERE Library.id_user='".$BD->real_escape_string($user["id"])."' and User.id=Library.id_user";
		
		$resultado3 = $BD->query($query3);
		
		while($row3 = $resultado3->fetch_assoc()) {
			$library[] = $row3;				
		}
		
		
		
			if($resultado->num_rows == 1) {
				$ok = password_verify($pass,$user['password']);
				if($ok) {
					//send your user to the browser encoded in the JSON format
					echo json_encode(array('status' => 'success', 'user' => $user, 'library' => $library, 'books' => $books));
				} else {
					echo json_encode(array('status' => 'error'));
				}
				//$resultado->close();
			} else {
				echo json_encode(array('status' => 'error'));
			}
		}
	} else {
		echo json_encode(array('status' => 'error'));
	}
	
?>