	$(document).on('deviceready', function() {
		app.init();
	});

	var scopes = [ 'https://www.googleapis.com/auth/userinfo.email'];

	var app = {
		client_id: '418327533943-kgr0sla2uidirrmi29js73ckbrhp7pdv.apps.googleusercontent.com',
		client_secret: 'V1jr4RC3Kx5RIiZP23s895H5',
		redirect_uri: 'http://localhost',
		scope: scopes.join(' '),
		init: function() {
			$('.social-btn a').on('click', function() {
				app.onLoginButtonClick();
			});		
			
		},
		
		onSignInPage : function() {
			//$.mobile.changePage("#home");
			var id_user = localStorage.getItem("userSigned");

			$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/preferences.php', cache:false, data:{"id_user":id_user}, success:function (response) {		
				// create a variable to hold the parsed output from the server
				var output = [];
				
				// if the PHP script returned a success
				if (response.status == 'success') {	
					
					var prefArray = response.user;
					if(response.user != null) {
						var preferences = {"name": prefArray.name, "surname" : prefArray.surname, "description" : prefArray.description, "author" : prefArray.author, "language" : prefArray.language, "genre" : prefArray.genre};

						localStorage.setItem("session", JSON.stringify(preferences));
					}
					
					$.mobile.changePage("#home");
				} else {
					// output an error message
					//alert("Error de inicio de sesión.");
					var error = "";
					for(key in response.errors) {
						error += response.errors[key] + "\n";
					}
					
					alert(error);
				}

				
				
			},  error: function (xhr, ajaxOptions, thrownError) {
								alert(xhr.status);
								alert(thrownError);
			}});
		},
		onSignInPageWithGoogle: function() {
			//Get the token, either from the cache
			//or by using the refresh token.
			googleapi.getToken({
				client_id: app.client_id,
				client_secret: app.client_secret
			}).then(function(data) {
				//Pass the token to the API call and return a new promise object
				return googleapi.userInfo({ access_token: data.access_token });
			}).done(function(user) {
				//alert(user.email);
				//Registrar un usuario por user.email y crear una password y una vez hecho esto, asignado el id del usuario
				// al localStorage["userSigned"].
				// make an AJAX call to your PHP script
				$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/registro-google.php',cache: false,data:{"username":user.email}, success:function (response) {
					
					// create a variable to hold the parsed output from the server
					var output = [];
					
					// if the PHP script returned a success
					if (response.status == 'success') {	
						var user_id = response.user;
						localStorage.setItem("userSigned", response.user);
						
						$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/preferences.php', cache:false, data:{"id_user":user_id}, success:function (response) {
						
							// create a variable to hold the parsed output from the server
							var output = [];
							
							// if the PHP script returned a success
							if (response.status == 'success') {	
								
								var prefArray = response.user;
								if(response.user != null) {
									var preferences = {"name": prefArray.name, "surname" : prefArray.surname, "descripcion" : prefArray.description, "author" : prefArray.author, "language" : prefArray.language, "genre" : prefArray.genre};
				
									localStorage.setItem("session", JSON.stringify(preferences));
								}
								
								$.mobile.changePage("#home");
							} else {
								// output an error message
								//alert("Error de inicio de sesión.");
								var error = "";
								for(key in response.errors) {
									error += response.errors[key] + "\n";
								}
								
								alert(error);
							}	
						},  error: function (xhr, ajaxOptions, thrownError) {
							alert(xhr.status);
							alert(thrownError);
						}});
					} else {
						// output an error message
						//alert("Error de inicio de sesión.");
						var error = "";
						for(key in response.errors) {
							error += response.errors[key] + "\n";
						}
						
						alert(error);
					}			
				},  error: function (xhr, ajaxOptions, thrownError) {
						alert(xhr.status);
						alert(thrownError);
				}});
			}).fail(function() {
				//If getting the token fails, or the token has been
				//revoked, show the login view.
				app.onSignOutPage();
			});
		},
		onSignOutPage: function() {
			$.post('https://accounts.google.com/logout',{})
			.done(function(data) {
				$.mobile.changePage("#index");	
			});				
		},
		onLoginButtonClick: function() {
			//Show the consent page
			googleapi.authorize({
				client_id: app.client_id,
				client_secret: app.client_secret,
				redirect_uri: app.redirect_uri,
				scope: app.scope
			}).done(function() {
				//Show the greet view if access is granted
				app.onSignInPageWithGoogle();
			}).fail(function(data) {
				alert("Error de inicio de sesión");
			});
		}
	};
	
	/**
	*	Funcionalidad del login y el registro
	**/
	
	$('#login').submit(function(e) { 
		e.preventDefault();
		// recolecta los valores que inserto el usuario
		var datosUsuario = $("#username").val();
		var datosPassword = $("#password").val();
		
		// make an AJAX call to your PHP script
		$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/login.php',data:$("#login").serialize(), success:function (response) {
			
			// create a variable to hold the parsed output from the server
			var output = [];
			
			// if the PHP script returned a success
			if (response.status == 'success') {
				var user_id = response.user.id;
				localStorage.setItem("userSigned", response.user.id);
				
				app.onSignInPage();	
				//}
			// if the PHP script returned an error
			} else {
				// output an error message
				alert("Error de inicio de sesión.");
			}

			
			
		},  error: function (xhr, ajaxOptions, thrownError) {
			alert(xhr.status);
			alert(thrownError);
		}});
	});
	
	$('#registro').submit(function(e) { 
		e.preventDefault();
		// recolecta los valores que inserto el usuario
		var datosUsuario = $("#username").val();
		var datosPassword = $("#password").val();
		
		// make an AJAX call to your PHP script
		$.ajax({dataType:'json', url:'http://pray4fun.x10host.com/market/php/registro.php',data:$("#registro").serialize(), success:function (response) {
			
			// create a variable to hold the parsed output from the server
			var output = [];
			
			// if the PHP script returned a success
			if (response.status == 'success') {	
				var user_id = response.user;
				localStorage.setItem("userSigned", response.user);
				
				app.onSignInPageWithGoogle();
			} else {
				// output an error message
				//alert("Error de inicio de sesión.");
				var error = "";
				for(key in response.errors) {
					error += response.errors[key] + "\n";
				}
				
				alert(error);
			}

			
			
		},  error: function (xhr, ajaxOptions, thrownError) {
			alert(xhr.status);
			alert(thrownError);
		}});
	});