﻿<?php
	// Varios defines para los parámetros de configuración de acceso a la BD y la URL desde la que se sirve la aplicación
	define('BD_HOST', 'localhost');
	define('BD_NAME', 'pray4fun_bookalive');
	define('BD_USER', 'pray4fun_balive');
	define('BD_PASS', 'A1!firo61');
	define('INSTALL', true );

	$BD = new mysqli(BD_HOST, BD_USER, BD_PASS, BD_NAME);
	if ( $BD->connect_errno ) {
	  echo "Error de conexión a la BD: (" . $BD->connect_errno . ") " . utf8_encode($BD->connect_error);
	  exit();
	}

	if ( ! $BD->set_charset("utf8")) {
	  echo "Error al configurar la codificación de la BD: (" . $BD->errno . ") " . utf8_encode($BD->error);
	  exit();
	}

	$result = array();
	
	$id_book = isset($_GET['id']) ? $_GET['id'] : null ;
	
	$query = "SELECT id, url FROM Book WHERE id='".$BD->real_escape_string($id_book)."'";
	$book = false;
	$resultado = $BD->query($query);

	$book = array();
	
	if($resultado->num_rows == 1) {
		while($row = $resultado->fetch_assoc()) {
			$book[] = $row;				
		}
		
		//send your user to the browser encoded in the JSON format
		echo json_encode(array('status' => 'success', 'book' => $book));
	} else {
		//if no records were found in the database then user an error message encoded in the JSON format
		echo json_encode(array('status' => 'error', 'book' => $book));
	}
	
	
	$resultado->close();


?>