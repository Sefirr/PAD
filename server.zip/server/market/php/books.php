﻿<?php
	// Varios defines para los parámetros de configuración de acceso a la BD y la URL desde la que se sirve la aplicación
	define('BD_HOST', 'localhost');
	define('BD_NAME', 'pray4fun_bookalive');
	define('BD_USER', 'pray4fun_balive');
	define('BD_PASS', 'A1!firo61');
	define('INSTALL', true );

	$BD = new mysqli(BD_HOST, BD_USER, BD_PASS, BD_NAME);
	if ( $BD->connect_errno ) {
	  echo "Error de conexión a la BD: (" . $BD->connect_errno . ") " . utf8_encode($BD->connect_error);
	  exit();
	}

	if ( ! $BD->set_charset("utf8")) {
	  echo "Error al configurar la codificación de la BD: (" . $BD->errno . ") " . utf8_encode($BD->error);
	  exit();
	}
	
	$language = isset($_GET['language']) ? $_GET['language'] : null ;
	$language = $BD->real_escape_string($language);
	$genre = isset($_GET['genre']) ? $_GET['genre'] : null ;
	$genre = $BD->real_escape_string($genre);
	
	if($language==1) {
		if($genre==1) {
			$query = "SELECT * FROM Book";
		} else {
			$query = "SELECT * FROM Book WHERE genre='".$genre."'";
		}
	} else {
		if($genre==1)
			$query = "SELECT * FROM Book WHERE language='".$language."'";
		else
			$query = "SELECT * FROM Book WHERE language='".$language."' AND genre='".$genre."'";
			
	}
	
	$books = false;
	
	$resultado = $BD->query($query);
	
	$books = array();
	
	if($resultado->num_rows > 0) {
		while($row = $resultado->fetch_assoc()) {
			$books[] = $row;				
		}
		
		//send your user to the browser encoded in the JSON format
		echo json_encode(array('status' => 'success', 'books' => $books));
	} else {
		//if no records were found in the database then user an error message encoded in the JSON format
		echo json_encode(array('status' => 'error', 'books' => $books));
	}
	
	
	
	$resultado->close();


?>