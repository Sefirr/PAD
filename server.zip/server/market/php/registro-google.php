﻿<?php
	// Varios defines para los parámetros de configuración de acceso a la BD y la URL desde la que se sirve la aplicación
	define('BD_HOST', 'localhost');
	define('BD_NAME', 'pray4fun_bookalive');
	define('BD_USER', 'pray4fun_balive');
	define('BD_PASS', 'A1!firo61');
	define('INSTALL', true );
	
	define('HTML5_EMAIL_REGEXP', '/^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/');


	$BD = new mysqli(BD_HOST, BD_USER, BD_PASS, BD_NAME);
	if ( $BD->connect_errno ) {
	  echo "Error de conexión a la BD: (" . $BD->connect_errno . ") " . utf8_encode($BD->connect_error);
	  exit();
	}

	if ( ! $BD->set_charset("utf8")) {
	  echo "Error al configurar la codificación de la BD: (" . $BD->errno . ") " . utf8_encode($BD->error);
	  exit();
	}

	$result = array();
	$okValidacion = TRUE;

	$username = isset($_GET['username']) ? $_GET['username'] : null ;
	
	$query = "SELECT * FROM User WHERE username='".$username."'";
	$resultado = $BD->query($query);
	$user = $resultado->fetch_assoc();
	
	if($user != null) {
		$okValidacion = FALSE;
	} else {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_-=+;:,.?";
		$length = 16;
		$pass = substr( str_shuffle( $chars ), 0, $length );
	}
	
	
	/*$email = isset($_GET['email']) ? $_GET['email'] : null ;

	if ( !$email ||  ! preg_match(HTML5_EMAIL_REGEXP, $email)) {
		$result[] = 'E-mail is invalid.';
		$okValidacion = FALSE;
	}*/


	if ( $okValidacion ) {
		
		
		$query = "INSERT INTO User (username,password) VALUES ('".$username."', '".$pass."')";
		$resultado = $BD->query($query);
		
		echo json_encode(array('status' => 'success', 'user' =>  $BD->insert_id));
		$user2 = $BD->insert_id;
		
		$query = "INSERT INTO Preferences (id) VALUES ('".$user2."')";
		$resultado = $BD->query($query);
		

			
	} else {
		echo json_encode(array('status' => 'success', 'user' => $user["id"]));	
	}
	
	
	
?>