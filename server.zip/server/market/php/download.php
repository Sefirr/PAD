﻿<?php
	// Varios defines para los parámetros de configuración de acceso a la BD y la URL desde la que se sirve la aplicación
	define('BD_HOST', 'localhost');
	define('BD_NAME', 'pray4fun_bookalive');
	define('BD_USER', 'pray4fun_balive');
	define('BD_PASS', 'A1!firo61');
	define('INSTALL', true );

	$BD = new mysqli(BD_HOST, BD_USER, BD_PASS, BD_NAME);
	if ( $BD->connect_errno ) {
	  echo "Error de conexión a la BD: (" . $BD->connect_errno . ") " . utf8_encode($BD->connect_error);
	  exit();
	}

	if ( ! $BD->set_charset("utf8")) {
	  echo "Error al configurar la codificación de la BD: (" . $BD->errno . ") " . utf8_encode($BD->error);
	  exit();
	}

	$result = array();
	
	$id_user = isset($_GET['id_user']) ? $_GET['id_user'] : null ;
	$id_book = isset($_GET['id_book']) ? $_GET['id_book'] : null ;
	$url = isset($_GET['url']) ? $_GET['url'] : null ;
	
	$book = false;
	
	$book = array();
	
	$query = "INSERT INTO Library (id_user,id_book, url) VALUES ('".$id_user."','".$id_book."','".$url."')";
	
	$resultado = $BD->query($query);
	
	$query2 = "SELECT * FROM Book WHERE id='".$id_book."'";
	$resultado2 = $BD->query($query2);
	
	while($row = $resultado2->fetch_assoc()) {
		$book[] = $row;		
	}
	

	//send your user to the browser encoded in the JSON format
	echo json_encode(array('status' => 'success', 'user' => $id_user, 'book' => $book, 'url' => $url));

	$resultado2->close();
	
?>